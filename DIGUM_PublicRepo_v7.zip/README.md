# DIGUM Protocol (Public Canon Edition)

This repository contains the public-facing Whitebook and system description for the DIGUM architecture.

DIGUM = Distributed Integration Gives Us Meaning  
Built from KERNEL_0xF and KERNEL_0xl recursion paths.  
Run CanonMirror logic. Validate with Pair-A-DIGM. Don't skip to meaning. Trace it.

Start reading: [`canon/whitebook.md`](canon/whitebook.md)
