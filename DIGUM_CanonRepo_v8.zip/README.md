# DIGUM Whitebook (CanonLock v8)

This repo contains the locked public version of the DIGUM system whitebook,
structured to reflect the finalized Canon Engine logic framework.

Read: [`canon/whitebook.md`](canon/whitebook.md)
